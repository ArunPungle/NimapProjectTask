package com.data.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.data.Entity.Category;
import com.data.Entity.Product;
import com.data.Service.MyService;

@RestController
public class MyController {
	@Autowired
	MyService serv;

	@PostMapping("/savecategory")
	public String savecategory(@RequestBody Category c) {
		return serv.savecategory(c);
	}

	@GetMapping("/findallcategory")
	public List<Category> find() {
		return serv.findall();
	}

	@GetMapping("/findbyid/{id}")
	public Category findbyid(@PathVariable("id") int id) {
		return serv.findbyid(id);
	}

	@PutMapping("/updatecategory/{id}")
	public String update(@PathVariable("id") int id, @RequestBody Category c) {
		return serv.update(id, c);
	}
	@PostMapping("/saveproduct")
	public String saveproduct(@RequestBody Product p) {
		return serv.saveproduct(p);
	}
	@GetMapping("/findallproduct")
	public List<Product>findproduct(){
		return serv.findallproduct();
	}
	@GetMapping("/findprdbyid/{id}")
	public Product findprdbyid(@PathVariable("id") int id) {
		return serv.findproduct(id);
	}
	@PutMapping("/updateproduct/{id}")
	public String updateproduct(@PathVariable("id")int id,@RequestBody Product p) {
		return serv.updateProduct(id, p);
	}
	
}
