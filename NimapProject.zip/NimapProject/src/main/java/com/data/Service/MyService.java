package com.data.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.data.Entity.Category;
import com.data.Entity.Product;
import com.data.Repository.CategoryRepository;
import com.data.Repository.ProductRepository;

@Service
public class MyService {
	@Autowired
	ProductRepository prd;
	@Autowired
	CategoryRepository catg;

	public String savecategory(Category c) {
		for (Product p : c.getProducts()) {
			p.setCat(c);
			;
		}
		catg.save(c);
		return "record added successfully";
	}

	public List<Category> findall() {
		return catg.findAll();
	}

	public Category findbyid(int id) {
		return catg.findById(id).orElse(null);
	}

	public String deletebyid(int id) {
		catg.deleteById(id);
		return "One Category Deleted Sucessfully";
	}

	public String update(int id, Category c) {
		Category existingcate = catg.findById(null).orElse(null);
		if (c != null) {
			if (c.getCname() != null) {
				existingcate.setCname(c.getCname());
			}
			List<Product> updatedproduct = c.getProducts();
			for (Product p : updatedproduct) {
				if (p.getPid() != 0) {
					System.out.println("null");
					Product existingprod = prd.findById(p.getPid()).orElse(null);
					existingprod.setPname(p.getPname());
				} else {
					p.getCat();
					existingcate.getProducts().add(p);
				}
			}
			catg.save(existingcate);
		}
		return "record updated sucessfully ";
	}

	public String saveproduct(Product p) {
		prd.save(p);
		return "One product added";
	}

	public List<Product> findallproduct() {
		return prd.findAll();
	}
	public Product findproduct(int pid) {

		return prd.findById(pid) .orElse(null);
	}
	public String deleteprbyid(int pid) {
		prd.deleteById(pid);
		return "one record deleted";
	}
	public String updateProduct(int pid,Product p1) {
		Product p2=prd.findById(pid) .orElse(null);
		if(p1!=null) {
			if(p1.getPname()!=null) {
				p2.setPname(p1.getPname());
			}
			if(p1.getPrice()!=0.0) {
				p2.setPrice(p1.getPrice());
			}
		}
		prd.save(p2);
		return "One record updated";
		
	}
	

}
